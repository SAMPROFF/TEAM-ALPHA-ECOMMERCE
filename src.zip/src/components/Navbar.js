import React from 'react'
const Navbar = () => {
  return (
    <div className='main'>
    <li><span>Azubi</span> FrontEnd</li>
    <div className='center-li'>
        <li><a href='home'>Home</a></li>
        <li><a href='About'>About</a></li>
        <li><a href='contact'>Contact</a></li>
        <li><a href='cart'>Cart</a></li>
    </div>
      <li><a href='login'><button className='btn'>Login</button></a></li>
    </div>
  )
}

export default Navbar
