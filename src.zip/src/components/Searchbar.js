import React from 'react'
import { FaBullseye } from 'react-icons/fa';
const Searchbar = () => {
  return (
    <div>
      <input type="text" placeholder='Search Products' className='Search' /> 
    </div>
  )
}

export default Searchbar
